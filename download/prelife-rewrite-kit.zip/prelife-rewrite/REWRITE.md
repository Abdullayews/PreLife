# REWRITE

Rewrite this app's frontend from scratch.

Keep how it works — same routes, same behavior, same words:

- locales az / en / ru under `/[locale]/…` — pages: welcome, home, gym, diet, meditation, library, subscription
- all copy lives in `messages/*.json` — render it as-is; don't rewrite the text
- day/night theming per module, photo hero galleries (dots-only switcher, slow autoplay, crossfade), CSS-only motion, reduced-motion safe, fully responsive

Throw away how it's built — your own layout, components and visual design.

`src/` is the behavior reference, `README.md` is the map. The word is: rewrite.
